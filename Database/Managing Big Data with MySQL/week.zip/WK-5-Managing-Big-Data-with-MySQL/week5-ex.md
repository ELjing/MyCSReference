> Exercise 1. How many distinct dates are there in the saledate column of the transaction
> table for each month/year combination in the database?

```mysql
SELECT EXTRACT(YEAR from SALEDATE) AS year_num, EXTRACT(MONTH from SALEDATE) AS month_num, COUNT(DISTINCT SALEDATE)
FROM TRNSACT
GROUP BY year_num, month_num
ORDER BY year_num DESC, month_num DESC;
```



> Exercise 2. Use a CASE statement within an aggregate function to determine which sku
> had the greatest total sales during the combined summer months of June, July, and August.

```mysql
SELECT SKU, SUM(SPRICE) AS total_sale 
FROM TRNSACT
WHERE STYPE = 'P'
  AND EXTRACT(MONTH from saledate) IN (6, 7, 8)
GROUP BY SKU
ORDER BY total_sale DESC;
```

```mysql
SELECT SKU, 
SUM(CASE 
      WHEN EXTRACT(MONTH from saledate) = 6 
      THEN amt ELSE 0
    END) AS June_sale,
SUM(CASE 
      WHEN EXTRACT(MONTH from saledate) = 7 
      THEN amt ELSE 0 
    END) AS July_sale,
SUM(CASE 
      WHEN EXTRACT(MONTH from saledate) = 8 
      THEN amt ELSE 0 
    END) AS August_sale,
June_sale + July_sale + August_sale AS summer_sale
FROM trnsact
WHERE stype = 'P'
GROUP BY SKU
ORDER BY summer_sale DESC;
```



> Exercise 3. How many distinct dates are there in the saledate column of the transaction table for each month/year/store combination in the database? Sort your results by the number of days per combination in ascending order.

```mysql
SELECT EXTRACT(MONTH from SALEDATE) AS month_num, EXTRACT(YEAR from SALEDATE) AS year_num, STORE, 
COUNT(DISTINCT SALEDATE) AS num_of_saledate
FROM TRNSACT
GROUP BY STORE, month_num, year_num
ORDER BY num_of_saledate ASC;
```



> Exercise 4. What is the average daily revenue for each store/month/year combination in the database? Calculate this by dividing the total revenue for a group by the number of sales days available in the transaction table for that group.

```mysql
SELECT store, EXTRACT(year from saledate) AS year_num, EXTRACT(month from saledate) AS month_num, 
COUNT(DISTINCT saledate) AS num_days, SUM(amt) AS total_revenue, total_revenue/num_days AS daily_avg
FROM TRNSACT
WHERE STYPE = 'P' AND STORE = 204
GROUP BY store, year_num, month_num
ORDER BY daily_avg DESC;
```

> Save your final queries that remove “bad data” for use in subsequent exercises. From now on (and in the graded quiz), when I ask for average daily revenue:
> • Only examine purchases (not returns)
> • Exclude all stores with less than 20 days of data
> • Exclude all data from August, 2005

```mysql
SELECT store, year_and_month, num_of_days,
total_revenue/num_of_days AS avg_daily_revenue
FROM (SELECT store, EXTRACT(YEAR FROM saledate) || EXTRACT(MONTH FROM saledate) AS year_and_month, SUM(AMT) AS total_revenue,
    COUNT(DISTINCT SALEDATE) AS num_of_days
    FROM trnsact
    WHERE stype= 'P' AND SALEDATE < '2005-08-01'
    GROUP BY store, year_and_month) AS clean_trnsact
WHERE num_of_days >= 20
ORDER BY avg_daily_revenue DESC;
```



> Exercise 5. What is the average daily revenue brought in by Dillard’s stores in areas of
> high, medium, or low levels of high school education?

```mysql
SELECT (CASE
        WHEN m.msa_high<=60 THEN 'low'
        WHEN m.msa_high>60 AND m.msa_high<=70 THEN 'medium'
        WHEN m.msa_high>70 THEN 'high'
        END) AS EdLevel, SUM(cleaned_tran.distinctsaledays) AS CleanSaleDates,           SUM(cleaned_tran.TotalRev) AS cleanedRev,
  (cleanedRev/cleanSaleDates) AS AvgDailyRev
FROM(SELECT EXTRACT(YEAR from saledate) || EXTRACT(MONTH from saledate) AS YearMonth,        store, COUNT(DISTINCT saledate) AS distinctsaledays, SUM(AMT) AS TotalRev
    FROM trnsact
    WHERE stype = 'P' and saledate<'2005-08-01'
    GROUP BY YearMonth, store
	HAVING COUNT(DISTINCT saledate)>=20) AS cleaned_tran JOIN store_msa m
  ON cleaned_tran.store=m.store
Group BY EdLevel;
```

```mysql
#my answer
SELECT
  (CASE
     WHEN (s.msa_high > 50 AND s.msa_high <= 60) THEN 'low'
     WHEN (s.msa_high > 60 AND s.msa_high <= 70) THEN 'medium'
     WHEN s.msa_high>70 THEN 'high'
   END) AS education, SUM(num_of_days) AS total_days,
   SUM(revenue) AS total_revenue, (total_revenue / total_days) AS avg_revenue
FROM
  (SELECT store,
     EXTRACT(YEAR FROM saledate) || EXTRACT(MONTH FROM saledate) AS year_and_month,        SUM(AMT) AS revenue,
     COUNT(DISTINCT SALEDATE) AS num_of_days
   FROM trnsact
   WHERE stype= 'P' AND SALEDATE < '2005-08-01'
   GROUP BY store, year_and_month) AS clean_trnsact JOIN store_msa s
  ON clean_trnsact.store = s.store
WHERE num_of_days >= 20
GROUP BY education;
```



> Exercise 6. Compare the average daily revenues of the stores with the highest median msa_income and the lowest median msa_income. In what city and state were these stores, and which store had a higher average daily revenue?

```mysql
SELECT
  s.city, s.state, SUM(num_of_days) AS total_days, 
  SUM(revenue) AS total_revenue, (total_revenue / total_days) AS avg_revenue
FROM
  (SELECT store,
     EXTRACT(YEAR FROM saledate) || EXTRACT(MONTH FROM saledate) AS year_and_month,        SUM(AMT) AS revenue,
     COUNT(DISTINCT saledate) AS num_of_days
   FROM trnsact
   WHERE stype= 'P' AND saledate < '2005-08-01'
   GROUP BY store, year_and_month) AS clean_trnsact JOIN 
     (SELECT state, city, store, msa_income
      FROM store_msa
      WHERE msa_income IN ( (SELECT MAX(msa_income) FROM store_msa),
                          (SELECT MIN(msa_income) FROM store_msa)) ) AS s
  ON clean_trnsact.store = s.store
WHERE num_of_days >= 20 
GROUP BY s.city, s.state
ORDER BY avg_revenue DESC;
```



> Exercise 7: What is the brand of the sku with the greatest standard deviation in sprice? Only examine skus that have been part of over 100 transactions.



```mysql
SELECT TOP 5 s.sku, s.brand, sku_stddev.stddev_sprice, sku_stddev.sale_num
FROM skuinfo s JOIN
  (SELECT sku, STDDEV_SAMP(sprice) AS stddev_sprice, COUNT(sprice) AS sale_num
   FROM Trnsact
   WHERE stype='p'
   HAVING sale_num>100
   GROUP BY sku) sku_stddev
ON s.sku=sku_stddev.sku
ORDER BY sku_stddev.stddev_sprice DESC;
```

```mysql
#my answer
SELECT TOP 5 s.sku, s.brand, std_sprice
FROM (SELECT sku, STDDEV_SAMP(sprice) AS std_sprice, COUNT(sprice) AS num_trnsact
      FROM trnsact
      WHERE stype = 'P'
      GROUP BY sku
      HAVING num_trnsact > 100) AS clean_trnsact JOIN skuinfo s
  ON clean_trnsact.sku = s.sku
ORDER BY std_sprice DESC;
```



> Exercise 8: Examine all the transactions for the sku with the greatest standard deviation in sprice, but only consider skus that are part of more than 100 transactions.



```mysql
#my answer
SELECT *
FROM (SELECT TOP 1 sku, STDDEV_SAMP(sprice) AS max_std_sprice,
      COUNT(sprice) AS num_trnsact
      FROM trnsact
      WHERE stype = 'P'
      GROUP BY sku
      HAVING num_trnsact > 100) AS clean_trnsact JOIN trnsact t
  ON clean_trnsact.sku = t.sku;
```

```mysql
SELECT t.sku, t.sprice
FROM trnsact t JOIN
  (SELECT TOP 1 sku, stddev_samp(sprice) AS stddev_sprice, COUNT(trannum) AS num_tran 
   FROM trnsact
   WHERE stype='P'
   GROUP BY sku
   HAVING num_tran>100
   ORDER BY stddev_sprice DESC) AS cleaned_data
     ON t.sku=cleaned_data.sku
ORDER BY t.sprice DESC;
```



> Exercise 9: What was the average daily revenue Dillard’s brought in during each month of the year?

```mysql
SELECT month_num, num_of_days,
total_revenue/num_of_days AS avg_daily_revenue
FROM
  (SELECT EXTRACT(MONTH FROM saledate) AS month_num, SUM(AMT) AS total_revenue,
   COUNT(DISTINCT SALEDATE) AS num_of_days
   FROM trnsact
   WHERE stype= 'P' AND SALEDATE < '2005-08-01'
   GROUP BY month_num) AS clean_trnsact
WHERE num_of_days >= 20
ORDER BY avg_daily_revenue DESC;
```



> Exercise 10: Which department, in which city and state of what store, had the greatest% increase in average daily sales revenue from November to December?

```mysql
#correct answer
SELECT s.store, s.city, s.state, d.deptdesc,
              sum(case when extract(month from saledate)=11 
                       then amt 
                       end) as November,
 COUNT(DISTINCT (case WHEN EXTRACT(MONTH from saledate) ='11' then saledate END)) as Nov_numdays,
       sum(case when extract(month from saledate)=12 
                then amt 
                end) as December,
 COUNT(DISTINCT (case WHEN EXTRACT(MONTH from saledate) ='12' then saledate END)) as Dec_numdays,
      ((December/Dec_numdays)-(November/Nov_numdays))/(November/Nov_numdays)*100 AS bump
FROM trnsact t JOIN strinfo s
ON t.store=s.store JOIN skuinfo si
ON t.sku=si.sku JOIN deptinfo d
ON si.dept=d.dept
WHERE t.stype='P' and t.store||EXTRACT(YEAR from t.saledate)||EXTRACT(MONTH from t.saledate) IN
    (SELECT store||EXTRACT(YEAR from saledate)||EXTRACT(MONTH from saledate)
    FROM trnsact 
    GROUP BY store, EXTRACT(YEAR from saledate), EXTRACT(MONTH from saledate)
    HAVING COUNT(DISTINCT saledate)>= 20)
GROUP BY s.store, s.city, s.state, d.deptdesc
HAVING November > 1000 AND December > 1000
ORDER BY bump DESC;
```



> Exercise 11: What is the city and state of the store that had the greatest decrease in average daily revenue from August to September?

```mysql
SELECT s.store, s.city, s.state,
  sum(case when extract(month from saledate)='8'
      then amt
      end) as august,
  COUNT(DISTINCT (case WHEN EXTRACT(MONTH from saledate) ='8' 
                  then saledate END)) as aug_numdays,
  sum(case when extract(month from saledate) = '9'
      then amt
      end) as september,
  COUNT(DISTINCT (case WHEN EXTRACT(MONTH from saledate) ='9' 
                  then saledate END)) as sep_numdays,
  august / aug_numdays as august_avg,
  september / sep_numdays as september_avg
FROM trnsact t JOIN strinfo s ON t.store=s.store
WHERE t.stype='P' AND t.saledate < '2005-08-01'
  AND t.store||EXTRACT(YEAR from t.saledate)||EXTRACT(MONTH from t.saledate) IN
    (SELECT store||EXTRACT(YEAR from saledate)||EXTRACT(MONTH from saledate)
    FROM trnsact
    GROUP BY store, EXTRACT(YEAR from saledate), EXTRACT(MONTH from saledate)
    HAVING COUNT(DISTINCT saledate)>= 20)
GROUP BY s.store, s.city, s.state;
```

> Exercise 12: Determine the month of maximum <u>total revenue</u> for each store. Count the number of stores whose month of maximum <u>total revenue</u> was in each of the twelve months. Then determine the month of maximum <u>average daily revenue</u>. Count the number of stores whose month of maximum <u>average daily revenue</u> was in each of the twelve months. How do they compare?


```mysql
SELECT store, month_num, num_of_days, 
total_revenue/num_of_days AS avg_daily_revenue,
ROW_NUMBER() OVER (ORDER BY clean_trnsact.total_revenue DESC) AS Rank_total,
ROW_NUMBER() OVER (ORDER BY avg_daily_revenue DESC) AS Rank_avg
FROM
  (SELECT EXTRACT(MONTH FROM saledate) AS month_num, SUM(AMT) AS total_revenue,
   COUNT(DISTINCT SALEDATE) AS num_of_days, store
   FROM trnsact
   WHERE stype= 'P' AND SALEDATE < '2005-08-01'
   GROUP BY month_num, store) AS clean_trnsact
WHERE num_of_days >= 20
ORDER BY month_num;
```





2. ```mysql
   SELECT COUNT(DISTINCT sku)
   FROM skuinfo
   WHERE brand = 'Polo fas' AND (size = 'XXL' OR color = 'black');
   #13623
   ```

3. ```mysql
   SELECT s.store, s.city, s.state, month_days
   FROM (SELECT store, EXTRACT(MONTH FROM saledate) AS month_num,
           COUNT(DISTINCT saledate) AS month_days
         FROM trnsact
         GROUP BY store, month_num
         HAVING month_days = 11) AS clean_trnsact JOIN store_msa s
     ON clean_trnsact.store = s.store;
   #Atlanta, GA
   ```

4. ```mysql
   SELECT t.sku,
     sum(case when extract(month from saledate)=11 
         then amt
         end) as November,
     sum(case when extract(month from saledate)=12 
         then amt 
         end) as December,
     (December - November) AS increase 
   FROM trnsact t JOIN strinfo s
   ON t.store = s.store
   WHERE t.stype='P' AND saledate < '2005-08-01'
     AND t.store||EXTRACT(YEAR from t.saledate)||EXTRACT(MONTH from t.saledate) IN
       (SELECT store||EXTRACT(YEAR from saledate)||EXTRACT(MONTH from saledate)
       FROM trnsact 
       GROUP BY store, EXTRACT(YEAR from saledate), EXTRACT(MONTH from saledate)
       HAVING COUNT(DISTINCT saledate)>= 20)
   GROUP BY t.sku
   ORDER BY increase DESC;
   #3949538
   ```

5. ```mysql
   SELECT s.vendor, COUNT(clean_trnsact.sku) AS null_sku_num
   FROM (SELECT DISTINCT t.sku FROM trnsact t) AS clean_trnsact
     LEFT JOIN (SELECT DISTINCT sk.sku FROM skstinfo sk) AS clean_skstinfo
     ON clean_trnsact.sku = clean_skstinfo.sku
     JOIN skuinfo s ON s.sku = clean_trnsact.sku
   WHERE clean_skstinfo.sku IS NULL
   GROUP BY s.vendor
   ORDER BY null_sku_num DESC;
   #5715232
   ```

6. ```mysql
   SELECT s.brand, stdsprice
   FROM (SELECT t.sku, STDDEV_SAMP(t.sprice) AS stdsprice, COUNT(t.sprice) AS salenum
         FROM trnsact t
         WHERE stype = 'P'
         GROUP BY t.sku
         HAVING salenum > 100) AS clean_trnsact
     JOIN skuinfo s ON clean_trnsact.sku = s.sku
   ORDER BY stdsprice DESC;
   #Hart Sch
   ```

7. ```mysql
   SELECT DISTINCT st.store, st.city, st.state, Evolution
   
   FROM
   
   (SELECT DISTINCT store,
   
   SUM(CASE WHEN EXTRACT(MONTH from saledate)='11' THEN amt END) AS sales_november,
   
   SUM(CASE WHEN EXTRACT(MONTH from saledate)='12' THEN amt END) AS sales_december,
   
   (COUNT(DISTINCT(CASE WHEN EXTRACT(MONTH from saledate)='11' THEN saledate END))) AS days_november,
   
   (COUNT(DISTINCT(CASE WHEN EXTRACT(MONTH from saledate)='12' THEN saledate END))) AS days_december,
   
   (sales_november/days_november) AS daily_sales_nov,
   
   (sales_december/days_december) AS daily_sales_dec,
   
   (daily_sales_dec-daily_sales_nov) AS Evolution

   FROM trnsact
   
   WHERE stype='p'
   
   GROUP BY store) AS NovDec_T
   
   JOIN strinfo st ON NovDec_T.store=st.store
   
   GROUP BY st.store, st.city, st.state, Evolution
   
   ORDER BY Evolution DESC;
   #LA
   ```
   
8. ```mysql
   SELECT s.store, s.city, s.state, year_and_month, num_of_days, msa_income,
   total_revenue/num_of_days AS avg_daily_revenue
   FROM (SELECT store, EXTRACT(YEAR FROM saledate) || EXTRACT(MONTH FROM saledate) AS year_and_month, SUM(AMT) AS total_revenue,
       COUNT(DISTINCT SALEDATE) AS num_of_days
       FROM trnsact
       WHERE stype= 'P' AND SALEDATE < '2005-08-01'
       GROUP BY store, year_and_month) AS clean_trnsact JOIN store_msa s
       ON s.store = clean_trnsact.store
   WHERE num_of_days >= 20
   ORDER BY msa_income DESC;
   #56099 AL
   ```
   
   ```mYsql
   SELECT s.store, s.city, s.state, s.msa_income,
      SUM(num_of_days) AS total_days,
      SUM(revenue) AS total_revenue, (total_revenue / total_days) AS avg_revenue
   FROM
     (SELECT store,
        EXTRACT(YEAR FROM saledate) || EXTRACT(MONTH FROM saledate) AS year_and_month, SUM(AMT) AS revenue,
        COUNT(DISTINCT SALEDATE) AS num_of_days
      FROM trnsact
      WHERE stype= 'P' AND SALEDATE < '2005-08-01'
      GROUP BY store, year_and_month) AS clean_trnsact JOIN 
      (SELECT store, city, state, msa_income,
       (CASE
        WHEN (msa_high > 50 AND msa_high <= 60) THEN 'low'
     WHEN (msa_high > 60 AND msa_high <= 70) THEN 'medium'
        WHEN msa_high>70 THEN 'high'
        END) AS education
       GROUP BY education
       FROM store_msa) AS s
     ON clean_trnsact.store = s.store
   WHERE num_of_days >= 20 AND s.education = 'medium'
   ORDER BY s.msa_income ASC;
   #
   ```
   
   
   
9. ```mysql
   SELECT store, 
       (CASE
          WHEN (msa_income >= 1 AND msa_income <= 20000) THEN 'low'
          WHEN (msa_income >= 20001 AND msa_income <= 30000) THEN 'med-low'
          WHEN (msa_income >= 30001 AND msa_income <= 40000) THEN 'med-high'
          WHEN (msa_income >= 40001 AND msa_income <= 60000) THEN 'high'
        END) AS income_label
   FROM store_msa s
   GROUP BY income_label, store;
   #low
   ```
   
   ```mysql
   SELECT income_label, 
   SUM(total_revenue)/SUM(num_of_days) AS avg_daily_revenue
FROM (SELECT store, EXTRACT(YEAR FROM saledate) || EXTRACT(MONTH FROM saledate) AS year_and_month, SUM(AMT) AS total_revenue,
       COUNT(DISTINCT SALEDATE) AS num_of_days
       FROM trnsact
       WHERE stype= 'P' AND SALEDATE < '2005-08-01'
       GROUP BY store, year_and_month) AS clean_trnsact JOIN 
     (SELECT store, 
       (CASE
          WHEN (msa_income >= 1 AND msa_income <= 20000) THEN 'low'
          WHEN (msa_income >= 20001 AND msa_income <= 30000) THEN 'med-low'
          WHEN (msa_income >= 30001 AND msa_income <= 40000) THEN 'med-high'
          WHEN (msa_income >= 40001 AND msa_income <= 60000) THEN 'high'
        END) AS income_label
   FROM store_msa
   GROUP BY income_label, store) AS s
       ON s.store = clean_trnsact.store
   WHERE num_of_days >= 20
   GROUP BY income_label
   ORDER BY avg_daily_revenue DESC;
   ```
   
10. ```mysql
    SELECT pop_label, 
    SUM(total_revenue)/SUM(num_of_days) AS avg_daily_revenue
    FROM (SELECT store, EXTRACT(YEAR FROM saledate) || EXTRACT(MONTH FROM saledate) AS year_and_month, SUM(AMT) AS total_revenue,
        COUNT(DISTINCT SALEDATE) AS num_of_days
        FROM trnsact
        WHERE stype= 'P' AND SALEDATE < '2005-08-01'
        GROUP BY store, year_and_month) AS clean_trnsact JOIN 
      (SELECT store, 
        (CASE
        WHEN msa_pop BETWEEN 1 and 100000 then 'very small'
        WHEN msa_pop BETWEEN 100001 and 200000 then 'small'
        WHEN msa_pop BETWEEN 200001 and 500000 then 'med small'
        WHEN msa_pop BETWEEN 500001 and 1000000 then 'med large'
        WHEN msa_pop BETWEEN 1000001 and 5000000 then 'large'
        WHEN msa_pop >= 5000000 then 'very large'
        END) AS pop_label
    FROM store_msa
    GROUP BY pop_label, store) AS s
        ON s.store = clean_trnsact.store
    WHERE num_of_days >= 20
    GROUP BY pop_label
    ORDER BY avg_daily_revenue DESC;
    #25452
    ```

11. ```mysql
    SELECT s.store, s.city, s.state, d.deptdesc,
                  sum(case when extract(month from saledate)=11 
                           then amt 
                           end) as November,
     COUNT(DISTINCT (case WHEN EXTRACT(MONTH from saledate) ='11' then saledate END)) as Nov_numdays,
           sum(case when extract(month from saledate)=12 
                    then amt 
                    end) as December,
     COUNT(DISTINCT (case WHEN EXTRACT(MONTH from saledate) ='12' then saledate END)) as Dec_numdays,
          ((December/Dec_numdays)-(November/Nov_numdays))/(November/Nov_numdays)*100 AS bump
    FROM trnsact t JOIN strinfo s
    ON t.store=s.store JOIN skuinfo si
    ON t.sku=si.sku JOIN deptinfo d
    ON si.dept=d.dept
    WHERE t.stype='P' and t.store||EXTRACT(YEAR from t.saledate)||EXTRACT(MONTH from t.saledate) IN
        (SELECT store||EXTRACT(YEAR from saledate)||EXTRACT(MONTH from saledate)
        FROM trnsact
        GROUP BY store, EXTRACT(YEAR from saledate), EXTRACT(MONTH from saledate)
        HAVING COUNT(DISTINCT saledate)>= 20)
    GROUP BY s.store, s.city, s.state, d.deptdesc
    HAVING November > 1000 AND December > 1000
    ORDER BY bump DESC;
    #KS
    ```

12. ```mysql
    select sk.dept, t.store, state, city,
    sum(case extract(month from saledate) when 9 then amt end) as sept_amt,
    count(distinct case extract(month from saledate) when 9 then saledate end) as sept_days,
    sum(case extract(month from saledate) when 8 then amt end) as aug_amt,
    count(distinct case extract(month from saledate) when 8 then saledate end) as aug_days,
    (sept_amt/sept_days) - (aug_amt/aug_days) as avg_decrease
    from (trnsact t join skuinfo sk on t.sku=sk.sku) join strinfo str on str.store=t.store
    where (extract(month from saledate)<>8 or extract(year from saledate)<>2005) and stype='p'
    group by sk.dept, t.store, state, city
    having sept_days>20 and aug_days>20 
    order by avg_decrease;
    #KY
    ```

13. ```mysql
    SELECT	CASE	when	max_month_table.month_num	=	1	then	'January' when	
    max_month_table.month_num	=	2	then	'February' when	
    max_month_table.month_num	=	3	then	'March' when	
    max_month_table.month_num	=	4	then	'April' when	
    max_month_table.month_num	=	5	then	'May' when	
    max_month_table.month_num	=	6	then	'June' when	
    max_month_table.month_num	=	7	then	'July' when	
    max_month_table.month_num	=	8	then	'August' when	
    max_month_table.month_num	=	9	then	'September' when	
    max_month_table.month_num	=	10	then	'October' when	
    max_month_table.month_num	=	11	then	'November' when	
    max_month_table.month_num	=	12	then	'December' END,	COUNT(*)
    FROM	(SELECT	DISTINCT	extract(year	from	saledate)	as	year_num,	extract(month	from	saledate)	as	month_num,	
    CASE	when	extract(year	from	saledate)	=	2005	AND	extract(month	from	saledate)	=	8	then	'exclude'	END	as	exclude_flag,	
    store,	SUM(amt)	AS	tot_sales,	COUNT	(DISTINCT	saledate)	as	numdays,		tot_sales/numdays	as	dailyrev, ROW_NUMBER	
    ()	over	(PARTITION	BY	store	ORDER	BY	dailyrev	DESC)	AS	month_rank
    FROM	trnsact
    WHERE	stype='P'	AND	exclude_flag	IS	NULL	AND	store||EXTRACT(YEAR	from			saledate)||EXTRACT(MONTH	from	
    saledate)	IN (SELECT	store||EXTRACT(YEAR	from	saledate)||EXTRACT(MONTH	from	saledate)
    FROM	trnsact	
    GROUP	BY	store,	EXTRACT(YEAR	from	saledate),	EXTRACT(MONTH	from	saledate)
    HAVING	COUNT(DISTINCT	saledate)>=	20)
    GROUP	BY	store,	month_num,	year_num
    HAVING	numdays>=20 QUALIFY	month_rank=12)	as	max_month_table
    GROUP	BY	max_month_table.month_num
    ORDER	BY	max_month_table.month_num;
    ```

14. ```mysql
    #A
    ```

15. ```mysql
    SELECT COUNT(sku) AS num_sku,
      extract(month from saledate) AS month_id
    FROM trnsact
    WHERE stype = 'R' AND saledate < '2005-08-01'
    GROUP BY month_id
    HAVING COUNT(DISTINCT saledate)>= 20
    ORDER BY num_sku DESC;
    #12
    ```

    10 13 14

